package android.support.v4.media;

import android.media.MediaMetadata;
import android.os.Parcel;

class c {
  public static void a(Object paramObject, Parcel paramParcel, int paramInt) {
    ((MediaMetadata)paramObject).writeToParcel(paramParcel, paramInt);
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/android/support/v4/media/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */