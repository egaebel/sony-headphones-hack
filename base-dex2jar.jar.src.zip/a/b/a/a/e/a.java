package a.b.a.a.e;

public final class a {
  public final String a;
  
  public final String b;
  
  public a(String paramString1, String paramString2) {
    this.a = paramString1;
    this.b = paramString2;
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/a/b/a/a/e/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */