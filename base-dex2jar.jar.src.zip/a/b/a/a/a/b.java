package a.b.a.a.a;

public enum b {
  a, b;
  
  static {
    b b1 = new b("SECOND", 0);
    a = b1;
    b b2 = new b("MILLISECOND", 1);
    b = b2;
    c = new b[] { b1, b2 };
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/a/b/a/a/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */