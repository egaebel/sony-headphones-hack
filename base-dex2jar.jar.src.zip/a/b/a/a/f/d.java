package a.b.a.a.f;

import com.sony.snc.ad.exception.VOCIError;
import com.sony.snc.ad.loader.c;
import com.sony.snc.ad.param.n;
import com.sony.snc.ad.sender.VOCIClickListener;
import com.sony.snc.ad.sender.k;

public final class d implements Runnable {
  public d(VOCIClickListener.b paramb, VOCIError paramVOCIError) {}
  
  public final void run() {
    c c = k.a(this.a.a);
    if (c != null)
      c.a(new n(this.b)); 
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/a/b/a/a/f/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */