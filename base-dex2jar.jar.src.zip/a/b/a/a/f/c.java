package a.b.a.a.f;

import com.sony.snc.ad.sender.VOCIClickListener;
import com.sony.snc.ad.sender.k;

public final class c implements Runnable {
  public c(VOCIClickListener.a parama) {}
  
  public final void run() {
    this.a.a.b();
    this.a.a.c().a(false);
    com.sony.snc.ad.loader.c c1 = k.a(this.a.a);
    if (c1 != null)
      c1.a(k.b(this.a.a)); 
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/a/b/a/a/f/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */