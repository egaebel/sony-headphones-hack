package androidx.core.h;

import android.view.View;

public interface o extends n {
  void a(View paramView, int paramInt);
  
  void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  void a(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3);
  
  boolean a(View paramView1, View paramView2, int paramInt1, int paramInt2);
  
  void b(View paramView1, View paramView2, int paramInt1, int paramInt2);
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/core/h/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */