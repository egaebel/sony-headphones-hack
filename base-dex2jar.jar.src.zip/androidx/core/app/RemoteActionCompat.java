package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import androidx.versionedparcelable.c;

public final class RemoteActionCompat implements c {
  public IconCompat a;
  
  public CharSequence b;
  
  public CharSequence c;
  
  public PendingIntent d;
  
  public boolean e;
  
  public boolean f;
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/core/app/RemoteActionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */