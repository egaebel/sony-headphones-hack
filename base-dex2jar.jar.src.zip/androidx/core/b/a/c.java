package androidx.core.b.a;

import android.view.SubMenu;

public interface c extends SubMenu, a {}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/core/b/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */