package androidx.core;

public final class a {
  public static final class a {
    public static final int alpha = 2130968626;
    
    public static final int font = 2130968880;
    
    public static final int fontProviderAuthority = 2130968882;
    
    public static final int fontProviderCerts = 2130968883;
    
    public static final int fontProviderFetchStrategy = 2130968884;
    
    public static final int fontProviderFetchTimeout = 2130968885;
    
    public static final int fontProviderPackage = 2130968886;
    
    public static final int fontProviderQuery = 2130968887;
    
    public static final int fontStyle = 2130968888;
    
    public static final int fontVariationSettings = 2130968889;
    
    public static final int fontWeight = 2130968890;
    
    public static final int ttcIndex = 2130969375;
  }
  
  public static final class b {
    public static final int notification_action_color_filter = 2131099949;
    
    public static final int notification_icon_bg_color = 2131099950;
    
    public static final int ripple_material_light = 2131099970;
    
    public static final int secondary_text_default_material_light = 2131099972;
  }
  
  public static final class c {
    public static final int compat_button_inset_horizontal_material = 2131165333;
    
    public static final int compat_button_inset_vertical_material = 2131165334;
    
    public static final int compat_button_padding_horizontal_material = 2131165335;
    
    public static final int compat_button_padding_vertical_material = 2131165336;
    
    public static final int compat_control_corner_material = 2131165337;
    
    public static final int compat_notification_large_icon_max_height = 2131165338;
    
    public static final int compat_notification_large_icon_max_width = 2131165339;
    
    public static final int notification_action_icon_size = 2131165560;
    
    public static final int notification_action_text_size = 2131165561;
    
    public static final int notification_big_circle_margin = 2131165562;
    
    public static final int notification_content_margin_start = 2131165563;
    
    public static final int notification_large_icon_height = 2131165564;
    
    public static final int notification_large_icon_width = 2131165565;
    
    public static final int notification_main_column_padding_top = 2131165566;
    
    public static final int notification_media_narrow_margin = 2131165567;
    
    public static final int notification_right_icon_size = 2131165568;
    
    public static final int notification_right_side_padding_top = 2131165569;
    
    public static final int notification_small_icon_background_padding = 2131165570;
    
    public static final int notification_small_icon_size_as_large = 2131165571;
    
    public static final int notification_subtext_size = 2131165572;
    
    public static final int notification_top_pad = 2131165573;
    
    public static final int notification_top_pad_large_text = 2131165574;
  }
  
  public static final class d {
    public static final int notification_action_background = 2131232159;
    
    public static final int notification_bg = 2131232160;
    
    public static final int notification_bg_low = 2131232161;
    
    public static final int notification_bg_low_normal = 2131232162;
    
    public static final int notification_bg_low_pressed = 2131232163;
    
    public static final int notification_bg_normal = 2131232164;
    
    public static final int notification_bg_normal_pressed = 2131232165;
    
    public static final int notification_icon_background = 2131232167;
    
    public static final int notification_template_icon_bg = 2131232169;
    
    public static final int notification_template_icon_low_bg = 2131232170;
    
    public static final int notification_tile_bg = 2131232171;
    
    public static final int notify_panel_notification_icon_bg = 2131232172;
  }
  
  public static final class e {
    public static final int accessibility_action_clickable_span = 2131296266;
    
    public static final int accessibility_custom_action_0 = 2131296267;
    
    public static final int accessibility_custom_action_1 = 2131296268;
    
    public static final int accessibility_custom_action_10 = 2131296269;
    
    public static final int accessibility_custom_action_11 = 2131296270;
    
    public static final int accessibility_custom_action_12 = 2131296271;
    
    public static final int accessibility_custom_action_13 = 2131296272;
    
    public static final int accessibility_custom_action_14 = 2131296273;
    
    public static final int accessibility_custom_action_15 = 2131296274;
    
    public static final int accessibility_custom_action_16 = 2131296275;
    
    public static final int accessibility_custom_action_17 = 2131296276;
    
    public static final int accessibility_custom_action_18 = 2131296277;
    
    public static final int accessibility_custom_action_19 = 2131296278;
    
    public static final int accessibility_custom_action_2 = 2131296279;
    
    public static final int accessibility_custom_action_20 = 2131296280;
    
    public static final int accessibility_custom_action_21 = 2131296281;
    
    public static final int accessibility_custom_action_22 = 2131296282;
    
    public static final int accessibility_custom_action_23 = 2131296283;
    
    public static final int accessibility_custom_action_24 = 2131296284;
    
    public static final int accessibility_custom_action_25 = 2131296285;
    
    public static final int accessibility_custom_action_26 = 2131296286;
    
    public static final int accessibility_custom_action_27 = 2131296287;
    
    public static final int accessibility_custom_action_28 = 2131296288;
    
    public static final int accessibility_custom_action_29 = 2131296289;
    
    public static final int accessibility_custom_action_3 = 2131296290;
    
    public static final int accessibility_custom_action_30 = 2131296291;
    
    public static final int accessibility_custom_action_31 = 2131296292;
    
    public static final int accessibility_custom_action_4 = 2131296293;
    
    public static final int accessibility_custom_action_5 = 2131296294;
    
    public static final int accessibility_custom_action_6 = 2131296295;
    
    public static final int accessibility_custom_action_7 = 2131296296;
    
    public static final int accessibility_custom_action_8 = 2131296297;
    
    public static final int accessibility_custom_action_9 = 2131296298;
    
    public static final int action_container = 2131296310;
    
    public static final int action_divider = 2131296312;
    
    public static final int action_image = 2131296314;
    
    public static final int action_text = 2131296324;
    
    public static final int actions = 2131296326;
    
    public static final int async = 2131296412;
    
    public static final int blocking = 2131296445;
    
    public static final int chronometer = 2131296528;
    
    public static final int dialog_button = 2131296655;
    
    public static final int forever = 2131296773;
    
    public static final int icon = 2131296826;
    
    public static final int icon_group = 2131296828;
    
    public static final int info = 2131296841;
    
    public static final int italic = 2131296864;
    
    public static final int line1 = 2131296917;
    
    public static final int line3 = 2131296920;
    
    public static final int normal = 2131297013;
    
    public static final int notification_background = 2131297016;
    
    public static final int notification_main_column = 2131297017;
    
    public static final int notification_main_column_container = 2131297018;
    
    public static final int right_icon = 2131297177;
    
    public static final int right_side = 2131297182;
    
    public static final int tag_accessibility_actions = 2131297369;
    
    public static final int tag_accessibility_clickable_spans = 2131297370;
    
    public static final int tag_accessibility_heading = 2131297371;
    
    public static final int tag_accessibility_pane_title = 2131297372;
    
    public static final int tag_screen_reader_focusable = 2131297373;
    
    public static final int tag_transition_group = 2131297374;
    
    public static final int tag_unhandled_key_event_manager = 2131297375;
    
    public static final int tag_unhandled_key_listeners = 2131297376;
    
    public static final int text = 2131297381;
    
    public static final int text2 = 2131297382;
    
    public static final int time = 2131297397;
    
    public static final int title = 2131297417;
  }
  
  public static final class f {
    public static final int status_bar_notification_info_maxnum = 2131361813;
  }
  
  public static final class g {
    public static final int custom_dialog = 2131492978;
    
    public static final int notification_action = 2131493136;
    
    public static final int notification_action_tombstone = 2131493137;
    
    public static final int notification_template_custom_big = 2131493144;
    
    public static final int notification_template_icon_group = 2131493145;
    
    public static final int notification_template_part_chronometer = 2131493149;
    
    public static final int notification_template_part_time = 2131493150;
  }
  
  public static final class h {
    public static final int status_bar_notification_info_overflow = 2131756914;
  }
  
  public static final class i {
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 2130968626 };
    
    public static final int ColorStateListItem_alpha = 2;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int[] FontFamily = new int[] { 2130968882, 2130968883, 2130968884, 2130968885, 2130968886, 2130968887 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130968880, 2130968888, 2130968889, 2130968890, 2130969375 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/core/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */