package androidx.core.graphics.drawable;

import android.graphics.drawable.Drawable;

public interface c {
  Drawable a();
  
  void a(Drawable paramDrawable);
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/core/graphics/drawable/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */