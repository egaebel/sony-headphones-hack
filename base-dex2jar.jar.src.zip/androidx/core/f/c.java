package androidx.core.f;

public interface c {
  boolean a(CharSequence paramCharSequence, int paramInt1, int paramInt2);
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/core/f/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */