package androidx.constraintlayout.solver;

public class c {
  g.a<b> a = new g.b<b>(256);
  
  g.a<SolverVariable> b = new g.b<SolverVariable>(256);
  
  SolverVariable[] c = new SolverVariable[32];
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/constraintlayout/solver/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */