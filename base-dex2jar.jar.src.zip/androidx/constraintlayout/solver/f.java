package androidx.constraintlayout.solver;

import java.util.ArrayList;

public class f {
  public long A;
  
  public long B;
  
  public ArrayList<String> C;
  
  public long D;
  
  public long a;
  
  public long b;
  
  public long c;
  
  public long d;
  
  public long e;
  
  public long f;
  
  public long g;
  
  public long h;
  
  public long i;
  
  public long j;
  
  public long k;
  
  public long l;
  
  public long m;
  
  public long n;
  
  public long o;
  
  public long p;
  
  public long q;
  
  public long r;
  
  public long s;
  
  public long t;
  
  public long u;
  
  public long v;
  
  public long w;
  
  public long x;
  
  public long y;
  
  public long z;
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("\n*** Metrics ***\nmeasures: ");
    stringBuilder.append(this.a);
    stringBuilder.append("\nadditionalMeasures: ");
    stringBuilder.append(this.b);
    stringBuilder.append("\nresolutions passes: ");
    stringBuilder.append(this.c);
    stringBuilder.append("\ntable increases: ");
    stringBuilder.append(this.d);
    stringBuilder.append("\nmaxTableSize: ");
    stringBuilder.append(this.p);
    stringBuilder.append("\nmaxVariables: ");
    stringBuilder.append(this.u);
    stringBuilder.append("\nmaxRows: ");
    stringBuilder.append(this.v);
    stringBuilder.append("\n\nminimize: ");
    stringBuilder.append(this.e);
    stringBuilder.append("\nminimizeGoal: ");
    stringBuilder.append(this.t);
    stringBuilder.append("\nconstraints: ");
    stringBuilder.append(this.f);
    stringBuilder.append("\nsimpleconstraints: ");
    stringBuilder.append(this.g);
    stringBuilder.append("\noptimize: ");
    stringBuilder.append(this.h);
    stringBuilder.append("\niterations: ");
    stringBuilder.append(this.i);
    stringBuilder.append("\npivots: ");
    stringBuilder.append(this.j);
    stringBuilder.append("\nbfs: ");
    stringBuilder.append(this.k);
    stringBuilder.append("\nvariables: ");
    stringBuilder.append(this.l);
    stringBuilder.append("\nerrors: ");
    stringBuilder.append(this.m);
    stringBuilder.append("\nslackvariables: ");
    stringBuilder.append(this.n);
    stringBuilder.append("\nextravariables: ");
    stringBuilder.append(this.o);
    stringBuilder.append("\nfullySolved: ");
    stringBuilder.append(this.q);
    stringBuilder.append("\ngraphOptimizer: ");
    stringBuilder.append(this.r);
    stringBuilder.append("\nresolvedWidgets: ");
    stringBuilder.append(this.s);
    stringBuilder.append("\noldresolvedWidgets: ");
    stringBuilder.append(this.A);
    stringBuilder.append("\nnonresolvedWidgets: ");
    stringBuilder.append(this.B);
    stringBuilder.append("\ncenterConnectionResolved: ");
    stringBuilder.append(this.w);
    stringBuilder.append("\nmatchConnectionResolved: ");
    stringBuilder.append(this.x);
    stringBuilder.append("\nchainConnectionResolved: ");
    stringBuilder.append(this.y);
    stringBuilder.append("\nbarrierConnectionResolved: ");
    stringBuilder.append(this.z);
    stringBuilder.append("\nproblematicsLayouts: ");
    stringBuilder.append(this.C);
    stringBuilder.append("\n");
    return stringBuilder.toString();
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/constraintlayout/solver/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */