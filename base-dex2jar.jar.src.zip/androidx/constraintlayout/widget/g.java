package androidx.constraintlayout.widget;

public final class g {
  public static final class a {
    public static final int bottom = 2131296447;
    
    public static final int end = 2131296708;
    
    public static final int gone = 2131296793;
    
    public static final int invisible = 2131296862;
    
    public static final int left = 2131296896;
    
    public static final int packed = 2131297048;
    
    public static final int parent = 2131297056;
    
    public static final int percent = 2131297061;
    
    public static final int right = 2131297170;
    
    public static final int spread = 2131297327;
    
    public static final int spread_inside = 2131297328;
    
    public static final int start = 2131297333;
    
    public static final int top = 2131297436;
    
    public static final int wrap = 2131297518;
  }
  
  public static final class b {
    public static final int[] ConstraintLayout_Layout = new int[] { 
        16842948, 16843039, 16843040, 16843071, 16843072, 2130968643, 2130968644, 2130968716, 2130968776, 2130968777, 
        2130969021, 2130969022, 2130969023, 2130969024, 2130969025, 2130969026, 2130969027, 2130969028, 2130969029, 2130969030, 
        2130969031, 2130969032, 2130969033, 2130969034, 2130969035, 2130969036, 2130969037, 2130969038, 2130969039, 2130969040, 
        2130969041, 2130969042, 2130969043, 2130969044, 2130969045, 2130969046, 2130969047, 2130969048, 2130969049, 2130969050, 
        2130969051, 2130969052, 2130969053, 2130969054, 2130969055, 2130969056, 2130969057, 2130969058, 2130969059, 2130969060, 
        2130969061, 2130969063, 2130969064, 2130969065, 2130969066, 2130969067, 2130969068, 2130969069, 2130969070, 2130969081 };
    
    public static final int ConstraintLayout_Layout_android_maxHeight = 2;
    
    public static final int ConstraintLayout_Layout_android_maxWidth = 1;
    
    public static final int ConstraintLayout_Layout_android_minHeight = 4;
    
    public static final int ConstraintLayout_Layout_android_minWidth = 3;
    
    public static final int ConstraintLayout_Layout_android_orientation = 0;
    
    public static final int ConstraintLayout_Layout_barrierAllowsGoneWidgets = 5;
    
    public static final int ConstraintLayout_Layout_barrierDirection = 6;
    
    public static final int ConstraintLayout_Layout_chainUseRtl = 7;
    
    public static final int ConstraintLayout_Layout_constraintSet = 8;
    
    public static final int ConstraintLayout_Layout_constraint_referenced_ids = 9;
    
    public static final int ConstraintLayout_Layout_layout_constrainedHeight = 10;
    
    public static final int ConstraintLayout_Layout_layout_constrainedWidth = 11;
    
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_creator = 12;
    
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf = 13;
    
    public static final int ConstraintLayout_Layout_layout_constraintBottom_creator = 14;
    
    public static final int ConstraintLayout_Layout_layout_constraintBottom_toBottomOf = 15;
    
    public static final int ConstraintLayout_Layout_layout_constraintBottom_toTopOf = 16;
    
    public static final int ConstraintLayout_Layout_layout_constraintCircle = 17;
    
    public static final int ConstraintLayout_Layout_layout_constraintCircleAngle = 18;
    
    public static final int ConstraintLayout_Layout_layout_constraintCircleRadius = 19;
    
    public static final int ConstraintLayout_Layout_layout_constraintDimensionRatio = 20;
    
    public static final int ConstraintLayout_Layout_layout_constraintEnd_toEndOf = 21;
    
    public static final int ConstraintLayout_Layout_layout_constraintEnd_toStartOf = 22;
    
    public static final int ConstraintLayout_Layout_layout_constraintGuide_begin = 23;
    
    public static final int ConstraintLayout_Layout_layout_constraintGuide_end = 24;
    
    public static final int ConstraintLayout_Layout_layout_constraintGuide_percent = 25;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_default = 26;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_max = 27;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_min = 28;
    
    public static final int ConstraintLayout_Layout_layout_constraintHeight_percent = 29;
    
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_bias = 30;
    
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle = 31;
    
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_weight = 32;
    
    public static final int ConstraintLayout_Layout_layout_constraintLeft_creator = 33;
    
    public static final int ConstraintLayout_Layout_layout_constraintLeft_toLeftOf = 34;
    
    public static final int ConstraintLayout_Layout_layout_constraintLeft_toRightOf = 35;
    
    public static final int ConstraintLayout_Layout_layout_constraintRight_creator = 36;
    
    public static final int ConstraintLayout_Layout_layout_constraintRight_toLeftOf = 37;
    
    public static final int ConstraintLayout_Layout_layout_constraintRight_toRightOf = 38;
    
    public static final int ConstraintLayout_Layout_layout_constraintStart_toEndOf = 39;
    
    public static final int ConstraintLayout_Layout_layout_constraintStart_toStartOf = 40;
    
    public static final int ConstraintLayout_Layout_layout_constraintTop_creator = 41;
    
    public static final int ConstraintLayout_Layout_layout_constraintTop_toBottomOf = 42;
    
    public static final int ConstraintLayout_Layout_layout_constraintTop_toTopOf = 43;
    
    public static final int ConstraintLayout_Layout_layout_constraintVertical_bias = 44;
    
    public static final int ConstraintLayout_Layout_layout_constraintVertical_chainStyle = 45;
    
    public static final int ConstraintLayout_Layout_layout_constraintVertical_weight = 46;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_default = 47;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_max = 48;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_min = 49;
    
    public static final int ConstraintLayout_Layout_layout_constraintWidth_percent = 50;
    
    public static final int ConstraintLayout_Layout_layout_editor_absoluteX = 51;
    
    public static final int ConstraintLayout_Layout_layout_editor_absoluteY = 52;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginBottom = 53;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginEnd = 54;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginLeft = 55;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginRight = 56;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginStart = 57;
    
    public static final int ConstraintLayout_Layout_layout_goneMarginTop = 58;
    
    public static final int ConstraintLayout_Layout_layout_optimizationLevel = 59;
    
    public static final int[] ConstraintLayout_placeholder = new int[] { 2130968778, 2130968836 };
    
    public static final int ConstraintLayout_placeholder_content = 0;
    
    public static final int ConstraintLayout_placeholder_emptyVisibility = 1;
    
    public static final int[] ConstraintSet = new int[] { 
        16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 
        16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 
        16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130968643, 2130968644, 2130968716, 
        2130968777, 2130969021, 2130969022, 2130969023, 2130969024, 2130969025, 2130969026, 2130969027, 2130969028, 2130969029, 
        2130969030, 2130969031, 2130969032, 2130969033, 2130969034, 2130969035, 2130969036, 2130969037, 2130969038, 2130969039, 
        2130969040, 2130969041, 2130969042, 2130969043, 2130969044, 2130969045, 2130969046, 2130969047, 2130969048, 2130969049, 
        2130969050, 2130969051, 2130969052, 2130969053, 2130969054, 2130969055, 2130969056, 2130969057, 2130969058, 2130969059, 
        2130969060, 2130969061, 2130969063, 2130969064, 2130969065, 2130969066, 2130969067, 2130969068, 2130969069, 2130969070 };
    
    public static final int ConstraintSet_android_alpha = 13;
    
    public static final int ConstraintSet_android_elevation = 26;
    
    public static final int ConstraintSet_android_id = 1;
    
    public static final int ConstraintSet_android_layout_height = 4;
    
    public static final int ConstraintSet_android_layout_marginBottom = 8;
    
    public static final int ConstraintSet_android_layout_marginEnd = 24;
    
    public static final int ConstraintSet_android_layout_marginLeft = 5;
    
    public static final int ConstraintSet_android_layout_marginRight = 7;
    
    public static final int ConstraintSet_android_layout_marginStart = 23;
    
    public static final int ConstraintSet_android_layout_marginTop = 6;
    
    public static final int ConstraintSet_android_layout_width = 3;
    
    public static final int ConstraintSet_android_maxHeight = 10;
    
    public static final int ConstraintSet_android_maxWidth = 9;
    
    public static final int ConstraintSet_android_minHeight = 12;
    
    public static final int ConstraintSet_android_minWidth = 11;
    
    public static final int ConstraintSet_android_orientation = 0;
    
    public static final int ConstraintSet_android_rotation = 20;
    
    public static final int ConstraintSet_android_rotationX = 21;
    
    public static final int ConstraintSet_android_rotationY = 22;
    
    public static final int ConstraintSet_android_scaleX = 18;
    
    public static final int ConstraintSet_android_scaleY = 19;
    
    public static final int ConstraintSet_android_transformPivotX = 14;
    
    public static final int ConstraintSet_android_transformPivotY = 15;
    
    public static final int ConstraintSet_android_translationX = 16;
    
    public static final int ConstraintSet_android_translationY = 17;
    
    public static final int ConstraintSet_android_translationZ = 25;
    
    public static final int ConstraintSet_android_visibility = 2;
    
    public static final int ConstraintSet_barrierAllowsGoneWidgets = 27;
    
    public static final int ConstraintSet_barrierDirection = 28;
    
    public static final int ConstraintSet_chainUseRtl = 29;
    
    public static final int ConstraintSet_constraint_referenced_ids = 30;
    
    public static final int ConstraintSet_layout_constrainedHeight = 31;
    
    public static final int ConstraintSet_layout_constrainedWidth = 32;
    
    public static final int ConstraintSet_layout_constraintBaseline_creator = 33;
    
    public static final int ConstraintSet_layout_constraintBaseline_toBaselineOf = 34;
    
    public static final int ConstraintSet_layout_constraintBottom_creator = 35;
    
    public static final int ConstraintSet_layout_constraintBottom_toBottomOf = 36;
    
    public static final int ConstraintSet_layout_constraintBottom_toTopOf = 37;
    
    public static final int ConstraintSet_layout_constraintCircle = 38;
    
    public static final int ConstraintSet_layout_constraintCircleAngle = 39;
    
    public static final int ConstraintSet_layout_constraintCircleRadius = 40;
    
    public static final int ConstraintSet_layout_constraintDimensionRatio = 41;
    
    public static final int ConstraintSet_layout_constraintEnd_toEndOf = 42;
    
    public static final int ConstraintSet_layout_constraintEnd_toStartOf = 43;
    
    public static final int ConstraintSet_layout_constraintGuide_begin = 44;
    
    public static final int ConstraintSet_layout_constraintGuide_end = 45;
    
    public static final int ConstraintSet_layout_constraintGuide_percent = 46;
    
    public static final int ConstraintSet_layout_constraintHeight_default = 47;
    
    public static final int ConstraintSet_layout_constraintHeight_max = 48;
    
    public static final int ConstraintSet_layout_constraintHeight_min = 49;
    
    public static final int ConstraintSet_layout_constraintHeight_percent = 50;
    
    public static final int ConstraintSet_layout_constraintHorizontal_bias = 51;
    
    public static final int ConstraintSet_layout_constraintHorizontal_chainStyle = 52;
    
    public static final int ConstraintSet_layout_constraintHorizontal_weight = 53;
    
    public static final int ConstraintSet_layout_constraintLeft_creator = 54;
    
    public static final int ConstraintSet_layout_constraintLeft_toLeftOf = 55;
    
    public static final int ConstraintSet_layout_constraintLeft_toRightOf = 56;
    
    public static final int ConstraintSet_layout_constraintRight_creator = 57;
    
    public static final int ConstraintSet_layout_constraintRight_toLeftOf = 58;
    
    public static final int ConstraintSet_layout_constraintRight_toRightOf = 59;
    
    public static final int ConstraintSet_layout_constraintStart_toEndOf = 60;
    
    public static final int ConstraintSet_layout_constraintStart_toStartOf = 61;
    
    public static final int ConstraintSet_layout_constraintTop_creator = 62;
    
    public static final int ConstraintSet_layout_constraintTop_toBottomOf = 63;
    
    public static final int ConstraintSet_layout_constraintTop_toTopOf = 64;
    
    public static final int ConstraintSet_layout_constraintVertical_bias = 65;
    
    public static final int ConstraintSet_layout_constraintVertical_chainStyle = 66;
    
    public static final int ConstraintSet_layout_constraintVertical_weight = 67;
    
    public static final int ConstraintSet_layout_constraintWidth_default = 68;
    
    public static final int ConstraintSet_layout_constraintWidth_max = 69;
    
    public static final int ConstraintSet_layout_constraintWidth_min = 70;
    
    public static final int ConstraintSet_layout_constraintWidth_percent = 71;
    
    public static final int ConstraintSet_layout_editor_absoluteX = 72;
    
    public static final int ConstraintSet_layout_editor_absoluteY = 73;
    
    public static final int ConstraintSet_layout_goneMarginBottom = 74;
    
    public static final int ConstraintSet_layout_goneMarginEnd = 75;
    
    public static final int ConstraintSet_layout_goneMarginLeft = 76;
    
    public static final int ConstraintSet_layout_goneMarginRight = 77;
    
    public static final int ConstraintSet_layout_goneMarginStart = 78;
    
    public static final int ConstraintSet_layout_goneMarginTop = 79;
    
    public static final int[] LinearConstraintLayout = new int[] { 16842948 };
    
    public static final int LinearConstraintLayout_android_orientation = 0;
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/constraintlayout/widget/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */