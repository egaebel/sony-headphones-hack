package androidx.fragment.app;

import android.util.AndroidRuntimeException;

final class SuperNotCalledException extends AndroidRuntimeException {
  public SuperNotCalledException(String paramString) {
    super(paramString);
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/fragment/app/SuperNotCalledException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */