package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;

interface e {
  float a(d paramd);
  
  void a();
  
  void a(d paramd, float paramFloat);
  
  void a(d paramd, Context paramContext, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3);
  
  void a(d paramd, ColorStateList paramColorStateList);
  
  float b(d paramd);
  
  void b(d paramd, float paramFloat);
  
  float c(d paramd);
  
  void c(d paramd, float paramFloat);
  
  float d(d paramd);
  
  float e(d paramd);
  
  void g(d paramd);
  
  void h(d paramd);
  
  ColorStateList i(d paramd);
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/cardview/widget/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */