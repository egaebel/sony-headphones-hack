package androidx.appcompat.view.menu;

public interface n {
  void a(g paramg);
  
  public static interface a {
    void a(i param1i, int param1Int);
    
    boolean a();
    
    i getItemData();
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/appcompat/view/menu/n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */