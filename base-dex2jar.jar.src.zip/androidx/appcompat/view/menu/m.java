package androidx.appcompat.view.menu;

import android.content.Context;

public interface m {
  void a(Context paramContext, g paramg);
  
  void a(g paramg, boolean paramBoolean);
  
  void a(a parama);
  
  void a(boolean paramBoolean);
  
  boolean a(g paramg, i parami);
  
  boolean a(r paramr);
  
  boolean b();
  
  boolean b(g paramg, i parami);
  
  public static interface a {
    void a(g param1g, boolean param1Boolean);
    
    boolean a(g param1g);
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/appcompat/view/menu/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */