package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.core.h.z;

public interface ad {
  ViewGroup a();
  
  z a(int paramInt, long paramLong);
  
  void a(int paramInt);
  
  void a(Drawable paramDrawable);
  
  void a(Menu paramMenu, m.a parama);
  
  void a(Window.Callback paramCallback);
  
  void a(m.a parama, g.a parama1);
  
  void a(aq paramaq);
  
  void a(CharSequence paramCharSequence);
  
  void a(boolean paramBoolean);
  
  Context b();
  
  void b(int paramInt);
  
  void b(CharSequence paramCharSequence);
  
  void b(boolean paramBoolean);
  
  void c(int paramInt);
  
  boolean c();
  
  void d();
  
  void d(int paramInt);
  
  CharSequence e();
  
  void e(int paramInt);
  
  void f();
  
  void f(int paramInt);
  
  void g();
  
  boolean h();
  
  boolean i();
  
  boolean j();
  
  boolean k();
  
  boolean l();
  
  void m();
  
  void n();
  
  int o();
  
  int p();
  
  Menu q();
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/appcompat/widget/ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */