package androidx.appcompat.widget;

import android.view.Menu;
import android.view.Window;
import androidx.appcompat.view.menu.m;

public interface ac {
  void a(int paramInt);
  
  void a(Menu paramMenu, m.a parama);
  
  boolean e();
  
  boolean f();
  
  boolean g();
  
  boolean h();
  
  boolean i();
  
  void j();
  
  void k();
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/appcompat/widget/ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */