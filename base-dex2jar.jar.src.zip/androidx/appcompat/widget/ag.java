package androidx.appcompat.widget;

import android.graphics.Rect;

public interface ag {
  void setOnFitSystemWindowsListener(a parama);
  
  public static interface a {
    void a(Rect param1Rect);
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/appcompat/widget/ag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */