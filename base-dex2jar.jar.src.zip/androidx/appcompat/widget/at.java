package androidx.appcompat.widget;

import android.content.res.Resources;
import android.widget.SpinnerAdapter;

public interface at extends SpinnerAdapter {
  Resources.Theme a();
  
  void a(Resources.Theme paramTheme);
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/appcompat/widget/at.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */