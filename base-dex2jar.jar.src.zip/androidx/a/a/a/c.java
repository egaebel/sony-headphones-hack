package androidx.a.a.a;

public abstract class c {
  public abstract void a(Runnable paramRunnable);
  
  public abstract void b(Runnable paramRunnable);
  
  public abstract boolean c();
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/a/a/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */