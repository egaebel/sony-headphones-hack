package androidx.lifecycle;

@Deprecated
public interface f extends h {}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/lifecycle/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */