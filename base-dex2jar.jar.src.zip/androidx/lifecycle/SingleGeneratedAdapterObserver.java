package androidx.lifecycle;

class SingleGeneratedAdapterObserver implements h {
  private final e a;
  
  SingleGeneratedAdapterObserver(e parame) {
    this.a = parame;
  }
  
  public void a(j paramj, Lifecycle.Event paramEvent) {
    this.a.a(paramj, paramEvent, false, null);
    this.a.a(paramj, paramEvent, true, null);
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/lifecycle/SingleGeneratedAdapterObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */