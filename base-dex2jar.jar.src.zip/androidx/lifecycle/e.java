package androidx.lifecycle;

public interface e {
  void a(j paramj, Lifecycle.Event paramEvent, boolean paramBoolean, n paramn);
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/lifecycle/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */