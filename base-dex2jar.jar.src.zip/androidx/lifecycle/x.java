package androidx.lifecycle;

public interface x {
  w getViewModelStore();
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/lifecycle/x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */