package androidx.lifecycle;

public interface p<T> {
  void a(T paramT);
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/lifecycle/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */