package androidx.activity;

import androidx.lifecycle.j;

public interface d extends j {
  OnBackPressedDispatcher getOnBackPressedDispatcher();
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/activity/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */