package androidx.multidex;

import android.app.Application;
import android.content.Context;

public class b extends Application {
  protected void attachBaseContext(Context paramContext) {
    super.attachBaseContext(paramContext);
    a.a((Context)this);
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/multidex/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */