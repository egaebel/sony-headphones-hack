package androidx.coordinatorlayout;

public final class a {
  public static final class a {
    public static final int alpha = 2130968626;
    
    public static final int coordinatorLayoutStyle = 2130968793;
    
    public static final int font = 2130968880;
    
    public static final int fontProviderAuthority = 2130968882;
    
    public static final int fontProviderCerts = 2130968883;
    
    public static final int fontProviderFetchStrategy = 2130968884;
    
    public static final int fontProviderFetchTimeout = 2130968885;
    
    public static final int fontProviderPackage = 2130968886;
    
    public static final int fontProviderQuery = 2130968887;
    
    public static final int fontStyle = 2130968888;
    
    public static final int fontVariationSettings = 2130968889;
    
    public static final int fontWeight = 2130968890;
    
    public static final int keylines = 2130969004;
    
    public static final int layout_anchor = 2130969014;
    
    public static final int layout_anchorGravity = 2130969015;
    
    public static final int layout_behavior = 2130969017;
    
    public static final int layout_dodgeInsetEdges = 2130969062;
    
    public static final int layout_insetEdge = 2130969072;
    
    public static final int layout_keyline = 2130969073;
    
    public static final int statusBarBackground = 2130969257;
    
    public static final int ttcIndex = 2130969375;
  }
  
  public static final class b {
    public static final int TextAppearance_Compat_Notification = 2131820985;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131820986;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131820988;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131820991;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131820993;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131821167;
    
    public static final int Widget_Compat_NotificationActionText = 2131821168;
    
    public static final int Widget_Support_CoordinatorLayout = 2131821215;
  }
  
  public static final class c {
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 2130968626 };
    
    public static final int ColorStateListItem_alpha = 2;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int[] CoordinatorLayout = new int[] { 2130969004, 2130969257 };
    
    public static final int[] CoordinatorLayout_Layout = new int[] { 16842931, 2130969014, 2130969015, 2130969017, 2130969062, 2130969072, 2130969073 };
    
    public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
    
    public static final int CoordinatorLayout_Layout_layout_anchor = 1;
    
    public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
    
    public static final int CoordinatorLayout_Layout_layout_behavior = 3;
    
    public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
    
    public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
    
    public static final int CoordinatorLayout_Layout_layout_keyline = 6;
    
    public static final int CoordinatorLayout_keylines = 0;
    
    public static final int CoordinatorLayout_statusBarBackground = 1;
    
    public static final int[] FontFamily = new int[] { 2130968882, 2130968883, 2130968884, 2130968885, 2130968886, 2130968887 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130968880, 2130968888, 2130968889, 2130968890, 2130969375 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/coordinatorlayout/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */