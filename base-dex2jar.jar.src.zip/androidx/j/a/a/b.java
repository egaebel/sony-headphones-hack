package androidx.j.a.a;

import android.graphics.drawable.Animatable;

public interface b extends Animatable {}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/j/a/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */