package androidx.h.a;

public interface f extends d {
  int a();
  
  long b();
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/h/a/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */