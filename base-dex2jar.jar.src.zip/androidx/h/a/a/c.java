package androidx.h.a.a;

import androidx.h.a.c;

public final class c implements c.c {
  public c a(c.b paramb) {
    return new b(paramb.a, paramb.b, paramb.c);
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/h/a/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */