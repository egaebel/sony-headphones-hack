package androidx.h.a;

import android.database.Cursor;
import android.util.Pair;
import java.io.Closeable;
import java.util.List;

public interface b extends Closeable {
  Cursor a(e parame);
  
  f a(String paramString);
  
  void a();
  
  Cursor b(String paramString);
  
  void b();
  
  void c();
  
  void c(String paramString);
  
  boolean d();
  
  boolean e();
  
  String f();
  
  List<Pair<String, String>> g();
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/h/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */