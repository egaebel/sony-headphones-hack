package androidx.h.a;

import java.io.Closeable;

public interface d extends Closeable {
  void a(int paramInt);
  
  void a(int paramInt, double paramDouble);
  
  void a(int paramInt, long paramLong);
  
  void a(int paramInt, String paramString);
  
  void a(int paramInt, byte[] paramArrayOfbyte);
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/h/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */