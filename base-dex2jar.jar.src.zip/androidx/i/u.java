package androidx.i;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

class u extends aa implements w {
  u(Context paramContext, ViewGroup paramViewGroup, View paramView) {
    super(paramContext, paramViewGroup, paramView);
  }
  
  static u a(ViewGroup paramViewGroup) {
    return (u)aa.d((View)paramViewGroup);
  }
  
  public void a(View paramView) {
    this.a.a(paramView);
  }
  
  public void b(View paramView) {
    this.a.b(paramView);
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/i/u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */