package androidx.i;

import android.graphics.drawable.Drawable;

interface ac {
  void a(Drawable paramDrawable);
  
  void b(Drawable paramDrawable);
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/i/ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */