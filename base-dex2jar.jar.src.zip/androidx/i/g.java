package androidx.i;

import android.graphics.Path;

public abstract class g {
  public abstract Path a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/i/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */