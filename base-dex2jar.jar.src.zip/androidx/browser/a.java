package androidx.browser;

public final class a {
  public static final class a {
    public static final int browser_actions_context_menu_max_width = 2131165320;
    
    public static final int browser_actions_context_menu_min_padding = 2131165321;
    
    public static final int compat_button_inset_horizontal_material = 2131165333;
    
    public static final int compat_button_inset_vertical_material = 2131165334;
    
    public static final int compat_button_padding_horizontal_material = 2131165335;
    
    public static final int compat_button_padding_vertical_material = 2131165336;
    
    public static final int compat_control_corner_material = 2131165337;
    
    public static final int compat_notification_large_icon_max_height = 2131165338;
    
    public static final int compat_notification_large_icon_max_width = 2131165339;
    
    public static final int notification_action_icon_size = 2131165560;
    
    public static final int notification_action_text_size = 2131165561;
    
    public static final int notification_big_circle_margin = 2131165562;
    
    public static final int notification_content_margin_start = 2131165563;
    
    public static final int notification_large_icon_height = 2131165564;
    
    public static final int notification_large_icon_width = 2131165565;
    
    public static final int notification_main_column_padding_top = 2131165566;
    
    public static final int notification_media_narrow_margin = 2131165567;
    
    public static final int notification_right_icon_size = 2131165568;
    
    public static final int notification_right_side_padding_top = 2131165569;
    
    public static final int notification_small_icon_background_padding = 2131165570;
    
    public static final int notification_small_icon_size_as_large = 2131165571;
    
    public static final int notification_subtext_size = 2131165572;
    
    public static final int notification_top_pad = 2131165573;
    
    public static final int notification_top_pad_large_text = 2131165574;
  }
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/browser/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */