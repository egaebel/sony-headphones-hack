package androidx.browser.a;

import android.net.Uri;
import android.os.Bundle;

public class a {
  public void a(int paramInt, Uri paramUri, boolean paramBoolean, Bundle paramBundle) {}
  
  public void a(int paramInt, Bundle paramBundle) {}
  
  public void a(Bundle paramBundle) {}
  
  public void a(String paramString, Bundle paramBundle) {}
  
  public void b(String paramString, Bundle paramBundle) {}
}


/* Location:              /home/egaebel/Programs/sony-headphones-hack/base-dex2jar.jar!/androidx/browser/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */